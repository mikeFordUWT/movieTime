package data;

public class DBMain {

	public static void main(String[] args) {
		DatabaseAccess dba = new DatabaseAccess();
	}
}
